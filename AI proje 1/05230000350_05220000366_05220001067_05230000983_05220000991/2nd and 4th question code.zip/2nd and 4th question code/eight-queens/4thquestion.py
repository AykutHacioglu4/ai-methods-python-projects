from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import confusion_matrix
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import cross_validate
from sklearn.pipeline import Pipeline

# Load dataset
data = load_breast_cancer()
X = data.data
y = data.target

# Split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Standardization
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# -------------------------------
# We used Random Forest and KNN as classifiers
# -------------------------------
rf = RandomForestClassifier()
rf.fit(X_train, y_train)

rf_pred = rf.predict(X_test)
rf_cm = confusion_matrix(y_test, rf_pred)

print("Random Forest Confusion Matrix:")
print(rf_cm)

# -------------------------------
# KNN
# -------------------------------
knn = KNeighborsClassifier(n_neighbors=5)
knn.fit(X_train, y_train)

knn_pred = knn.predict(X_test)
knn_cm = confusion_matrix(y_test, knn_pred)

print("\nKNN Confusion Matrix:")
print(knn_cm)

# --- New Instance Prediction ---

new_instance = [X_test[0]]

# We applied the same scaling
new_instance_scaled = scaler.transform(new_instance)

# Predictions
rf_prediction = rf.predict(new_instance_scaled)
knn_prediction = knn.predict(new_instance_scaled)

# Class names
target_names = data.target_names

print("\n--- New Instance Prediction ---")

print(f"Random Forest Prediction: {rf_prediction[0]} -> {target_names[rf_prediction[0]]}")
print(f"KNN Prediction: {knn_prediction[0]} -> {target_names[knn_prediction[0]]}")

# Define scoring metrics
scoring = ['accuracy', 'precision_macro', 'recall_macro']

# Pipeline for Random Forest
rf_pipeline = Pipeline([
    ('scaler', StandardScaler()),
    ('rf', RandomForestClassifier())
])

# Pipeline for KNN
knn_pipeline = Pipeline([
    ('scaler', StandardScaler()),
    ('knn', KNeighborsClassifier(n_neighbors=5))
])

# Cross-validation (3-fold)
rf_scores = cross_validate(rf_pipeline, X, y, cv=3, scoring=scoring)
knn_scores = cross_validate(knn_pipeline, X, y, cv=3, scoring=scoring)

# Print results
print("\n--- 3-Fold Cross Validation Results ---")

print("\nRandom Forest:")
print("Accuracy:", rf_scores['test_accuracy'].mean())
print("Precision:", rf_scores['test_precision_macro'].mean())
print("Recall:", rf_scores['test_recall_macro'].mean())

print("\nKNN:")
print("Accuracy:", knn_scores['test_accuracy'].mean())
print("Precision:", knn_scores['test_precision_macro'].mean())
print("Recall:", knn_scores['test_recall_macro'].mean())
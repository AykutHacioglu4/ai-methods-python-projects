import random
import time
import matplotlib.pyplot as plt

N = 8

# -------------------------------
# Heuristic: number of conflicts
# -------------------------------
def heuristic(board):
    conflicts = 0
    for i in range(N):
        for j in range(i + 1, N):
            # same row
            if board[i] == board[j]:
                conflicts += 1
            # diagonal
            if abs(board[i] - board[j]) == abs(i - j):
                conflicts += 1
    return conflicts


# -------------------------------
# Generate random board
# -------------------------------
def random_board():
    return [random.randint(0, N - 1) for _ in range(N)]


# -------------------------------
# Get best neighbor
# -------------------------------
def best_neighbor(board):
    best = board[:]
    best_h = heuristic(board)

    for col in range(N):
        original_row = board[col]
        for row in range(N):
            if row == original_row:
                continue

            new_board = board[:]
            new_board[col] = row
            h = heuristic(new_board)

            if h < best_h:
                best = new_board
                best_h = h

    return best, best_h


# -------------------------------
# Hill Climbing with Random Restart
# -------------------------------
def solve():
    current = random_board()
    current_h = heuristic(current)

    moves = 0
    restarts = 0

    while current_h != 0:
        neighbor, neighbor_h = best_neighbor(current)

        if neighbor_h < current_h:
            current = neighbor
            current_h = neighbor_h
            moves += 1
        else:
            # stuck -> random restart
            current = random_board()
            current_h = heuristic(current)
            restarts += 1

    return current, moves, restarts


# -------------------------------
# Print board
# -------------------------------
def print_board(board):
    for r in range(N):
        row = ""
        for c in range(N):
            if board[c] == r:
                row += "Q "
            else:
                row += ". "
        print(row)
    print()


# -------------------------------
# Run 10 trials
# -------------------------------
def run_trials():
    results = []

    for i in range(10):
        start = time.perf_counter()

        solution, moves, restarts = solve()

        end = time.perf_counter()
        elapsed = end - start

        results.append((moves, restarts, elapsed))

        print(f"Trial {i+1}")
        print_board(solution)
        print("Final Heuristic:", heuristic(solution))
        draw_board(solution, i+1)
        print(f"Moves: {moves}, Restarts: {restarts}, Time: {elapsed:.6f}s")
        print("-" * 40)

    return results


# -------------------------------
# Print table
# -------------------------------
def print_table(results):
    print("\nFINAL TABLE")
    print("Moves | Restarts | Time (s)")
    print("-----------------------------")

    total_moves = 0
    total_restarts = 0
    total_time = 0

    for (m, r, t) in results:
        print(f"{m:5} | {r:8} | {t:.6f}")
        total_moves += m
        total_restarts += r
        total_time += t

    print("-----------------------------")
    print(f"{total_moves/10:.2f} | {total_restarts/10:.2f} | {total_time/10:.6f}")

def draw_board(board, trial_num):
    fig, ax = plt.subplots()
    
    # Draw a board (8x8)
    for row in range(N):
        for col in range(N):
            color = "#EEEED2" if (row + col) % 2 == 0 else "#769656"
            ax.add_patch(plt.Rectangle((col, row), 1, 1, color=color))

    # Queen'leri koy
    for col in range(N):
        row = board[col]
        ax.text(col + 0.5, row + 0.5, '♛',
                ha='center', va='center', fontsize=20, color='black')

    ax.set_xlim(0, N)
    ax.set_ylim(0, N)
    ax.set_xticks([])
    ax.set_yticks([])
    ax.set_title(f"Trial {trial_num}")

    plt.gca().invert_yaxis()
    
    # save as PNG to put in project template
    plt.savefig(f"board_trial_{trial_num}.png")
    plt.close()


# -------------------------------
# MAIN
# -------------------------------
if __name__ == "__main__":
    results = run_trials()
    print_table(results)
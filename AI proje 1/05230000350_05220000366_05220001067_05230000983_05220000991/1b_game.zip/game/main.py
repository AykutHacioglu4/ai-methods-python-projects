import pygame
import random
import sys

# --- Configuration & Constants ---
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
FPS = 60

# Colors
BACKGROUND = (25, 20, 30)
WHITE      = (255, 255, 255)
BLACK      = (0, 0, 0)
RED        = (255, 50, 50)
GOLD       = (255, 215, 0)   # Star color
HEART_CLR  = (255, 105, 180) # Heart color
PLAYER_COLORS = [(0, 120, 255), (50, 205, 50), (148, 0, 211), (255, 165, 0)]

# Game Settings
PLAYER_SIZE = 40
OBSTACLE_WIDTH = 30
OBSTACLE_HEIGHT = 60
COLLECTIBLE_SIZE = 20
FLOOR_Y = SCREEN_HEIGHT - 50
CEILING_Y = 50

class GravityRunner:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        pygame.display.set_caption("Gravity Runner - Enhanced")
        self.clock = pygame.time.Clock()
        self.font = pygame.font.SysFont("Arial", 32)
        self.large_font = pygame.font.SysFont("Arial", 64)
        self.reset_game()

    def reset_game(self):
        """Initializes or resets all game variables."""
        self.player_rect = pygame.Rect(100, FLOOR_Y - PLAYER_SIZE, PLAYER_SIZE, PLAYER_SIZE)
        self.player_color = PLAYER_COLORS[0]
        self.gravity_up = False
        
        self.obstacles = []
        self.stars = []
        self.hearts = []
        
        self.spawn_timer = 0
        self.score = 0
        self.lives = 3
        self.base_speed = 7
        self.game_active = True
        self.start_ticks = pygame.time.get_ticks()

    def spawn_entities(self):
        """Handles spawning logic for obstacles and collectibles."""
        self.spawn_timer += 1
        if self.spawn_timer >= 60:  # Spawn every 1 second approx
            self.spawn_timer = 0
            
            # 1. Spawn Obstacle
            on_top = random.choice([True, False])
            y_obs = CEILING_Y if on_top else FLOOR_Y - OBSTACLE_HEIGHT
            self.obstacles.append(pygame.Rect(SCREEN_WIDTH, y_obs, OBSTACLE_WIDTH, OBSTACLE_HEIGHT))
            
            # 2. Randomly spawn Star (30% chance)
            if random.random() < 0.3:
                y_star = CEILING_Y + 20 if not on_top else FLOOR_Y - 40
                self.stars.append(pygame.Rect(SCREEN_WIDTH + 100, y_star, COLLECTIBLE_SIZE, COLLECTIBLE_SIZE))
                
            # 3. Randomly spawn Heart (15% chance)
            if random.random() < 0.15:
                y_heart = CEILING_Y + 20 if on_top else FLOOR_Y - 40
                self.hearts.append(pygame.Rect(SCREEN_WIDTH + 200, y_heart, COLLECTIBLE_SIZE, COLLECTIBLE_SIZE))

    def update(self):
        """Updates game logic, movement, and collisions."""
        if not self.game_active:
            return

        # Difficulty: Increase speed based on score
        current_speed = self.base_speed + (self.score // 50)

        # Gravity Toggle
        if self.gravity_up:
            self.player_rect.top = CEILING_Y
        else:
            self.player_rect.bottom = FLOOR_Y

        # Move and check Obstacles
        for obs in self.obstacles[:]:
            obs.x -= current_speed
            if obs.colliderect(self.player_rect):
                self.lives -= 1
                self.obstacles.remove(obs)
                if self.lives <= 0:
                    self.game_active = False
            elif obs.right < 0:
                self.obstacles.remove(obs)

        # Move and check Stars
        for star in self.stars[:]:
            star.x -= current_speed
            if star.colliderect(self.player_rect):
                self.player_color = random.choice(PLAYER_COLORS)
                self.stars.remove(star)
            elif star.right < 0:
                self.stars.remove(star)

        # Move and check Hearts
        for heart in self.hearts[:]:
            heart.x -= current_speed
            if heart.colliderect(self.player_rect):
                if self.lives < 3:
                    self.lives += 1
                self.hearts.remove(heart)
            elif heart.right < 0:
                self.hearts.remove(heart)

        # Update Score
        self.score = (pygame.time.get_ticks() - self.start_ticks) // 100

    def draw(self):
        """Renders all elements to the screen."""
        self.screen.fill(BACKGROUND)
        
        # Draw Floor/Ceiling
        pygame.draw.rect(self.screen, WHITE, (0, 0, SCREEN_WIDTH, CEILING_Y))
        pygame.draw.rect(self.screen, WHITE, (0, FLOOR_Y, SCREEN_WIDTH, SCREEN_HEIGHT - FLOOR_Y))

        if self.game_active:
            # Draw Player
            pygame.draw.rect(self.screen, self.player_color, self.player_rect)

            # Draw Entities
            for obs in self.obstacles:
                pygame.draw.rect(self.screen, RED, obs)
            for star in self.stars:
                pygame.draw.rect(self.screen, GOLD, star)
            for heart in self.hearts:
                pygame.draw.rect(self.screen, HEART_CLR, heart)

            # UI: Score
            score_txt = self.font.render(f"Score: {self.score}", True, BLACK)
            self.screen.blit(score_txt, (SCREEN_WIDTH // 2 - 50, 10))

            # UI: Lives (Small red rectangles)
            for i in range(self.lives):
                pygame.draw.rect(self.screen, RED, (20 + (i * 30), 15, 20, 20))
        else:
            # Game Over Screen
            msg = self.large_font.render("GAME OVER", True, RED)
            retry = self.font.render("Press 'R' to Restart", True, WHITE)
            self.screen.blit(msg, (SCREEN_WIDTH // 2 - 150, SCREEN_HEIGHT // 2 - 50))
            self.screen.blit(retry, (SCREEN_WIDTH // 2 - 110, SCREEN_HEIGHT // 2 + 30))

        pygame.display.flip()

    def run(self):
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_SPACE and self.game_active:
                        self.gravity_up = not self.gravity_up
                    if event.key == pygame.K_r and not self.game_active:
                        self.reset_game()

            if self.game_active:
                self.spawn_entities()
                self.update()
            
            self.draw()
            self.clock.tick(FPS)

if __name__ == "__main__":
    game = GravityRunner()
    game.run()